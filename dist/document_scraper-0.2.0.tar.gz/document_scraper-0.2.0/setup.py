"""
Installation script for the document_scraper module.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="document-scraper",
    version="0.2.0",
    author="DocScraper Developer",
    author_email="developer@example.com",
    description="A tool for downloading documentation websites and converting them to Markdown",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/IAM_timmy1t/document_scraper",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Documentation",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Text Processing :: Markup :: Markdown",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.28.1",
        "beautifulsoup4>=4.11.1",
        "html2text>=2020.1.16",
        "click>=8.1.3",
        "tqdm>=4.64.1",
        "validators>=0.20.0",
        "python-slugify>=7.0.0",
        "colorama>=0.4.6",
        "urllib3>=1.26.0"
    ],
    entry_points={
        "console_scripts": [
            "docscraper=document_scraper.cli:main"
        ]
    }
)
